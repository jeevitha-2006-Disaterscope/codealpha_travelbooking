import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { FilterSidebar } from '../components/FilterSidebar';
import { PackageCard } from '../components/PackageCard';
import { HeroSearch } from '../components/HeroSearch';

export function SearchResultsPage() {
  const results = [
    {
      id: '1',
      image: '',
      title: 'Luxury Maldives Resort Experience',
      location: 'Maldives',
      duration: '7 Days',
      groupSize: 'Up to 10',
      rating: 4.9,
      reviews: 342,
      price: 2499,
    },
    {
      id: '2',
      image: '',
      title: 'Swiss Alps Adventure Tour',
      location: 'Switzerland',
      duration: '10 Days',
      groupSize: 'Up to 15',
      rating: 4.8,
      reviews: 289,
      price: 3299,
    },
    {
      id: '3',
      image: '',
      title: 'Tokyo City Lights & Culture',
      location: 'Japan',
      duration: '6 Days',
      groupSize: 'Up to 12',
      rating: 4.7,
      reviews: 421,
      price: 1899,
    },
    {
      id: '4',
      image: '',
      title: 'Iceland Northern Lights Quest',
      location: 'Iceland',
      duration: '5 Days',
      groupSize: 'Up to 8',
      rating: 4.9,
      reviews: 198,
      price: 2199,
    },
    {
      id: '5',
      image: '',
      title: 'African Safari Adventure',
      location: 'Kenya',
      duration: '8 Days',
      groupSize: 'Up to 12',
      rating: 4.8,
      reviews: 267,
      price: 2899,
    },
    {
      id: '6',
      image: '',
      title: 'Mediterranean Cruise Deluxe',
      location: 'Mediterranean',
      duration: '12 Days',
      groupSize: 'Unlimited',
      rating: 4.9,
      reviews: 532,
      price: 3499,
    },
    {
      id: '7',
      image: '',
      title: 'Santorini Sunset Romance',
      location: 'Greece',
      duration: '5 Days',
      groupSize: 'Up to 8',
      rating: 4.9,
      reviews: 412,
      price: 1799,
    },
    {
      id: '8',
      image: '',
      title: 'Bali Temple & Beach Retreat',
      location: 'Indonesia',
      duration: '8 Days',
      groupSize: 'Up to 14',
      rating: 4.7,
      reviews: 356,
      price: 1599,
    },
    {
      id: '9',
      image: '',
      title: 'Paris Romance & Luxury',
      location: 'France',
      duration: '6 Days',
      groupSize: 'Up to 10',
      rating: 4.8,
      reviews: 487,
      price: 2299,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      {/* Sticky Search Bar */}
      <div className="bg-white border-b-2 border-gray-400 py-4 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <HeroSearch />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6 border-b-2 border-gray-300 pb-4">
          <h2 className="text-gray-900 mb-2">[Search Results]</h2>
          <p className="text-gray-600">Found {results.length} trips</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <FilterSidebar />
          </div>

          {/* Results Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {results.map((result) => (
                <PackageCard key={result.id} {...result} />
              ))}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
