import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { Star, MapPin, Clock, Users, Check, Calendar } from 'lucide-react';

export function PackageDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const packageData = {
    title: 'Luxury Maldives Resort Experience',
    location: 'Maldives',
    rating: 4.9,
    reviews: 342,
    price: 2499,
    duration: '7 Days / 6 Nights',
    groupSize: 'Up to 10 people',
    image: '',
  };

  const itinerary = [
    { day: 1, title: 'Arrival & Welcome', description: 'Arrive at airport. Transfer to resort. Welcome cocktail. Evening dinner.' },
    { day: 2, title: 'Water Sports & Relaxation', description: 'Morning snorkeling. Lunch at restaurant. Afternoon spa. Sunset cruise.' },
    { day: 3, title: 'Island Hopping', description: 'Full day island tour. Visit villages. Private picnic. Culture experience.' },
    { day: 4, title: 'Diving Adventure', description: 'Scuba diving excursion. Lunch onboard. Leisure activities. Beach dinner.' },
    { day: 5, title: 'Luxury & Leisure', description: 'Private breakfast. Full day leisure. Optional activities. Photography session.' },
    { day: 6, title: 'Memorable Experiences', description: 'Morning yoga. Cooking class. Afternoon pool. Farewell dinner.' },
    { day: 7, title: 'Departure', description: 'Breakfast. Souvenir shopping. Check-out and transfer to airport.' },
  ];

  const inclusions = [
    '6 nights accommodation',
    'Daily meals included',
    'Return transfers',
    'Water sports activities',
    'Spa treatment (2 sessions)',
    'Island hopping tour',
    'Diving with equipment',
    'Professional guide',
    'Travel insurance',
    '24/7 support',
  ];

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'itinerary', label: 'Itinerary' },
    { id: 'inclusions', label: 'Inclusions' },
    { id: 'reviews', label: 'Reviews' },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      {/* Hero Banner - Wireframe */}
      <div className="relative h-96 bg-gray-300 border-b-4 border-gray-400">
        <div className="w-full h-full flex items-center justify-center">
          <span className="text-gray-700 text-xl">[HERO BANNER: Destination Image]</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white border-2 border-gray-400 p-8">
              <div className="flex items-center gap-2 text-gray-800 mb-3 bg-gray-200 p-3 border border-gray-400">
                <MapPin className="w-5 h-5" />
                <span>{packageData.location}</span>
              </div>

              <h1 className="text-gray-900 mb-4 border-b-2 border-gray-300 pb-4">{packageData.title}</h1>

              <div className="flex items-center gap-6 mb-6 text-gray-800 flex-wrap">
                <div className="flex items-center gap-2 border-2 border-gray-400 px-4 py-2">
                  <Star className="w-5 h-5 text-gray-700" />
                  <span>{packageData.rating}</span>
                  <span className="text-gray-600">({packageData.reviews} reviews)</span>
                </div>
                <div className="flex items-center gap-2 border border-gray-400 px-3 py-1">
                  <Clock className="w-5 h-5" />
                  <span>{packageData.duration}</span>
                </div>
                <div className="flex items-center gap-2 border border-gray-400 px-3 py-1">
                  <Users className="w-5 h-5" />
                  <span>{packageData.groupSize}</span>
                </div>
              </div>

              {/* Tabs */}
              <div className="border-b-2 border-gray-300 mb-6">
                <div className="flex gap-8">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`pb-4 relative ${
                        activeTab === tab.id
                          ? 'text-gray-900 border-b-4 border-gray-800'
                          : 'text-gray-600'
                      }`}
                    >
                      [{tab.label}]
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div>
                  <div className="border-2 border-dashed border-gray-400 p-6 mb-6 bg-gray-50">
                    <p className="text-gray-700 leading-relaxed">
                      [Description: Experience ultimate tropical paradise. This luxury package offers perfect blend of 
                      relaxation, adventure, and romance. Stay in exclusive villa with direct access to waters...]
                    </p>
                  </div>
                  <h3 className="text-gray-900 mb-4 border-b border-gray-300 pb-2">Trip Highlights</h3>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {[
                      'Private villa accommodation',
                      'Snorkeling & diving',
                      'Island hopping',
                      'Sunset cruises',
                      'Spa treatments',
                      'Authentic cuisine',
                    ].map((highlight, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-gray-700 border border-gray-300 p-2">
                        <Check className="w-5 h-5 text-gray-700 flex-shrink-0" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {activeTab === 'itinerary' && (
                <div>
                  <div className="space-y-6">
                    {itinerary.map((day) => (
                      <div key={day.day} className="flex gap-4 border-l-4 border-gray-400 pl-4">
                        <div className="flex-shrink-0">
                          <div className="w-12 h-12 border-2 border-gray-700 bg-white flex items-center justify-center text-gray-900">
                            {day.day}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-gray-900 mb-2">Day {day.day}: {day.title}</h4>
                          <p className="text-gray-600 text-sm border-l-2 border-gray-300 pl-3">{day.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'inclusions' && (
                <div>
                  <h3 className="text-gray-900 mb-4 border-b border-gray-300 pb-2">What's Included</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {inclusions.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-3 border-2 border-gray-400">
                        <Check className="w-5 h-5 text-gray-700 flex-shrink-0" />
                        <span className="text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  {[
                    { name: 'Sarah Johnson', rating: 5, date: 'Nov 2024', comment: 'Absolutely incredible experience! Perfect service.' },
                    { name: 'Michael Chen', rating: 5, date: 'Oct 2024', comment: 'Best vacation of my life. Amazing villa and diving.' },
                    { name: 'Emma Williams', rating: 4, date: 'Sep 2024', comment: 'Beautiful destination. Would love one more day.' },
                  ].map((review, idx) => (
                    <div key={idx} className="p-6 border-2 border-gray-400">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-gray-900">{review.name}</h4>
                        <span className="text-sm text-gray-500">{review.date}</span>
                      </div>
                      <div className="flex gap-1 mb-3">
                        {[...Array(review.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-gray-700" />
                        ))}
                      </div>
                      <p className="text-gray-600 text-sm border-l-2 border-gray-300 pl-3">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Gallery */}
              <div className="mt-10">
                <h3 className="text-gray-900 mb-6 border-b-2 border-gray-300 pb-3">[Photo Gallery]</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {[1, 2, 3, 4, 5, 6].map((idx) => (
                    <div key={idx} className="relative aspect-square border-2 border-gray-400 bg-gray-300 flex items-center justify-center">
                      <span className="text-gray-600 text-sm">[IMG {idx}]</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Booking Card */}
          <div className="lg:col-span-1">
            <div className="bg-white border-2 border-gray-400 p-6 sticky top-24">
              <div className="text-center mb-6 pb-6 border-b-2 border-gray-300">
                <div className="text-gray-600 mb-2 text-sm">[Starting from]</div>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-gray-900 text-4xl">${packageData.price}</span>
                  <span className="text-gray-600">/person</span>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">[Select Date]</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="date"
                      className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm text-gray-700 mb-2 block">[Travelers]</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <select className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300 appearance-none">
                      <option>1 Person</option>
                      <option>2 People</option>
                      <option>3 People</option>
                      <option>4+ People</option>
                    </select>
                  </div>
                </div>
              </div>

              <button
                onClick={() => navigate(`/booking/${id}`)}
                className="w-full bg-gray-800 hover:bg-gray-900 text-white py-4 border-2 border-gray-900 mb-4"
              >
                [Book This Trip]
              </button>

              <div className="text-center text-sm text-gray-600 border-t-2 border-gray-300 pt-4">
                <p>Free cancellation up to 24 hours</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
