import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { HeroSearch } from '../components/HeroSearch';
import { DestinationCard } from '../components/DestinationCard';
import { PackageCard } from '../components/PackageCard';
import { Plane, Tag, Shield, Headphones } from 'lucide-react';

export function HomePage() {
  const destinations = [
    {
      image: '',
      name: 'Santorini',
      country: 'Greece',
      trips: 24,
    },
    {
      image: '',
      name: 'Bali',
      country: 'Indonesia',
      trips: 32,
    },
    {
      image: '',
      name: 'Paris',
      country: 'France',
      trips: 41,
    },
    {
      image: '',
      name: 'Dubai',
      country: 'UAE',
      trips: 28,
    },
  ];

  const packages = [
    {
      id: '1',
      image: '',
      title: 'Luxury Maldives Resort Experience',
      location: 'Maldives',
      duration: '7 Days',
      groupSize: 'Up to 10',
      rating: 4.9,
      reviews: 342,
      price: 2499,
    },
    {
      id: '2',
      image: '',
      title: 'Swiss Alps Adventure Tour',
      location: 'Switzerland',
      duration: '10 Days',
      groupSize: 'Up to 15',
      rating: 4.8,
      reviews: 289,
      price: 3299,
    },
    {
      id: '3',
      image: '',
      title: 'Tokyo City Lights & Culture',
      location: 'Japan',
      duration: '6 Days',
      groupSize: 'Up to 12',
      rating: 4.7,
      reviews: 421,
      price: 1899,
    },
    {
      id: '4',
      image: '',
      title: 'Iceland Northern Lights Quest',
      location: 'Iceland',
      duration: '5 Days',
      groupSize: 'Up to 8',
      rating: 4.9,
      reviews: 198,
      price: 2199,
    },
    {
      id: '5',
      image: '',
      title: 'African Safari Adventure',
      location: 'Kenya',
      duration: '8 Days',
      groupSize: 'Up to 12',
      rating: 4.8,
      reviews: 267,
      price: 2899,
    },
    {
      id: '6',
      image: '',
      title: 'Mediterranean Cruise Deluxe',
      location: 'Mediterranean',
      duration: '12 Days',
      groupSize: 'Unlimited',
      rating: 4.9,
      reviews: 532,
      price: 3499,
    },
  ];

  const offers = [
    {
      id: '7',
      image: '',
      title: 'Tropical Paradise Getaway',
      location: 'Caribbean',
      duration: '7 Days',
      groupSize: 'Up to 20',
      rating: 4.6,
      reviews: 156,
      price: 1499,
      originalPrice: 1999,
    },
    {
      id: '8',
      image: '',
      title: 'New York City Explorer',
      location: 'USA',
      duration: '5 Days',
      groupSize: 'Up to 15',
      rating: 4.7,
      reviews: 289,
      price: 1299,
      originalPrice: 1799,
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section - Wireframe */}
      <div className="relative h-[600px] border-b-4 border-gray-400">
        <div className="w-full h-full bg-gray-300 flex items-center justify-center">
          <div className="text-center border-4 border-dashed border-gray-500 p-12">
            <span className="text-gray-700">[HERO IMAGE: Tropical Beach]</span>
          </div>
        </div>
        <div className="absolute inset-0 bg-gray-900/20" />
        
        {/* Floating Elements Wireframe */}
        <div className="absolute top-20 right-20">
          <div className="border-2 border-gray-600 bg-white/80 p-4">
            <Plane className="w-8 h-8 text-gray-700" />
          </div>
        </div>

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-gray-900 px-4 max-w-4xl">
            <h1 className="text-gray-900 text-5xl md:text-6xl mb-6 border-4 border-dashed border-gray-700 p-6 bg-white/80">
              [Discover Your Next Adventure]
            </h1>
            <p className="text-xl text-gray-800 border-2 border-gray-600 p-4 bg-white/80">
              [Subtitle: Explore destinations and create memories]
            </p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <HeroSearch />
      </div>

      {/* Features */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-4 p-4 bg-white border-2 border-gray-400">
            <div className="border-2 border-gray-500 p-3">
              <Tag className="w-6 h-6 text-gray-700" />
            </div>
            <div>
              <h4 className="text-gray-900">Best Prices</h4>
              <p className="text-sm text-gray-600">Low rates</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 bg-white border-2 border-gray-400">
            <div className="border-2 border-gray-500 p-3">
              <Shield className="w-6 h-6 text-gray-700" />
            </div>
            <div>
              <h4 className="text-gray-900">Safe Travel</h4>
              <p className="text-sm text-gray-600">Secure booking</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 bg-white border-2 border-gray-400">
            <div className="border-2 border-gray-500 p-3">
              <Headphones className="w-6 h-6 text-gray-700" />
            </div>
            <div>
              <h4 className="text-gray-900">24/7 Support</h4>
              <p className="text-sm text-gray-600">Always available</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-4 bg-white border-2 border-gray-400">
            <div className="border-2 border-gray-500 p-3">
              <Plane className="w-6 h-6 text-gray-700" />
            </div>
            <div>
              <h4 className="text-gray-900">Easy Booking</h4>
              <p className="text-sm text-gray-600">Quick process</p>
            </div>
          </div>
        </div>
      </div>

      {/* Popular Destinations */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="text-center mb-12 border-b-2 border-gray-300 pb-8">
          <h2 className="text-gray-900 mb-4">[Popular Destinations]</h2>
          <p className="text-gray-600">Explore the world's most beautiful places</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((dest, idx) => (
            <DestinationCard key={idx} {...dest} />
          ))}
        </div>
      </div>

      {/* Recommended Packages */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20" id="packages">
        <div className="text-center mb-12 border-b-2 border-gray-300 pb-8">
          <h2 className="text-gray-900 mb-4">[Recommended Packages]</h2>
          <p className="text-gray-600">Handpicked tours for the perfect vacation</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => (
            <PackageCard key={pkg.id} {...pkg} />
          ))}
        </div>
      </div>

      {/* Special Offers */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20" id="deals">
        <div className="text-center mb-12 border-b-2 border-gray-300 pb-8">
          <h2 className="text-gray-900 mb-4">[Special Offers]</h2>
          <p className="text-gray-600">Limited time deals you don't want to miss</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {offers.map((offer) => (
            <PackageCard key={offer.id} {...offer} />
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
