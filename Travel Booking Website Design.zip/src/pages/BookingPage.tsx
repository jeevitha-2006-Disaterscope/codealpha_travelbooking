import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { User, Mail, Phone, MapPin, Check } from 'lucide-react';

export function BookingPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);

  const packageData = {
    title: 'Luxury Maldives Resort Experience',
    location: 'Maldives',
    duration: '7 Days / 6 Nights',
    date: 'Dec 15, 2024',
    travelers: 2,
    pricePerPerson: 2499,
    image: '',
  };

  const totalPrice = packageData.pricePerPerson * packageData.travelers;
  const tax = totalPrice * 0.1;
  const grandTotal = totalPrice + tax;

  const steps = [
    { number: 1, title: 'Traveler Details', icon: User },
    { number: 2, title: 'Review & Confirm', icon: Check },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-gray-900 mb-8 border-b-2 border-gray-400 pb-4">[Complete Your Booking]</h2>

        {/* Progress Steps */}
        <div className="mb-12 bg-white border-2 border-gray-400 p-6">
          <div className="flex items-center justify-center gap-4">
            {steps.map((s, idx) => (
              <div key={s.number} className="flex items-center">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 border-2 flex items-center justify-center ${
                      step >= s.number
                        ? 'border-gray-800 bg-gray-800 text-white'
                        : 'border-gray-400 bg-white text-gray-500'
                    }`}
                  >
                    <s.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Step {s.number}</div>
                    <div className={step >= s.number ? 'text-gray-900' : 'text-gray-500'}>
                      {s.title}
                    </div>
                  </div>
                </div>
                {idx < steps.length - 1 && (
                  <div
                    className={`w-24 h-1 mx-4 ${
                      step > s.number ? 'bg-gray-800' : 'bg-gray-300'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-2">
            <div className="bg-white border-2 border-gray-400 p-8">
              {step === 1 && (
                <>
                  <h3 className="text-gray-900 mb-6 border-b border-gray-300 pb-3">[Traveler Information]</h3>

                  {/* Lead Traveler */}
                  <div className="mb-8 border-2 border-gray-300 p-6">
                    <h4 className="text-gray-900 mb-4 flex items-center gap-2">
                      <User className="w-5 h-5 text-gray-700" />
                      Lead Traveler
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm text-gray-700 mb-2 block">[First Name *]</label>
                        <input
                          type="text"
                          placeholder="John"
                          className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-700 mb-2 block">[Last Name *]</label>
                        <input
                          type="text"
                          placeholder="Doe"
                          className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                        />
                      </div>
                      <div>
                        <label className="text-sm text-gray-700 mb-2 block">[Email *]</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                          <input
                            type="email"
                            placeholder="john@example.com"
                            className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm text-gray-700 mb-2 block">[Phone *]</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                          <input
                            type="tel"
                            placeholder="+1 (555) 000-0000"
                            className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                          />
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <label className="text-sm text-gray-700 mb-2 block">[Address *]</label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                          <input
                            type="text"
                            placeholder="123 Main Street, City, Country"
                            className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Additional Traveler */}
                  {packageData.travelers > 1 && (
                    <div className="mb-8 border-2 border-gray-300 p-6">
                      <h4 className="text-gray-900 mb-4 flex items-center gap-2">
                        <User className="w-5 h-5 text-gray-700" />
                        Additional Traveler
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-700 mb-2 block">[First Name *]</label>
                          <input
                            type="text"
                            placeholder="Jane"
                            className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-gray-700 mb-2 block">[Last Name *]</label>
                          <input
                            type="text"
                            placeholder="Doe"
                            className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Special Requests */}
                  <div className="mb-8">
                    <label className="text-sm text-gray-700 mb-2 block">[Special Requests (Optional)]</label>
                    <textarea
                      rows={4}
                      placeholder="Dietary restrictions, accessibility needs, special occasions..."
                      className="w-full px-4 py-3 bg-white border-2 border-gray-300 resize-none"
                    />
                  </div>

                  <button
                    onClick={() => setStep(2)}
                    className="w-full bg-gray-800 hover:bg-gray-900 text-white py-4 border-2 border-gray-900"
                  >
                    [Continue to Review]
                  </button>
                </>
              )}

              {step === 2 && (
                <>
                  <h3 className="text-gray-900 mb-6 border-b border-gray-300 pb-3">[Review Your Booking]</h3>

                  <div className="space-y-6">
                    <div className="p-6 border-2 border-gray-400">
                      <h4 className="text-gray-900 mb-4 border-b border-gray-300 pb-2">Trip Details</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Destination:</span>
                          <span className="text-gray-900">{packageData.location}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Duration:</span>
                          <span className="text-gray-900">{packageData.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Departure Date:</span>
                          <span className="text-gray-900">{packageData.date}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Travelers:</span>
                          <span className="text-gray-900">{packageData.travelers} People</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-6 border-2 border-gray-400">
                      <h4 className="text-gray-900 mb-4 border-b border-gray-300 pb-2">Traveler Information</h4>
                      <div className="space-y-2">
                        <p className="text-gray-700">John Doe (Lead Traveler)</p>
                        <p className="text-gray-600 text-sm">john@example.com • +1 (555) 000-0000</p>
                        {packageData.travelers > 1 && (
                          <p className="text-gray-700 mt-3">Jane Doe</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 border-2 border-gray-400">
                      <input type="checkbox" className="mt-1 border-2 border-gray-400" />
                      <p className="text-sm text-gray-700">
                        [ ] I agree to Terms & Conditions and Privacy Policy
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4 mt-8">
                    <button
                      onClick={() => setStep(1)}
                      className="flex-1 bg-white border-2 border-gray-400 hover:bg-gray-100 text-gray-900 py-4"
                    >
                      [Back]
                    </button>
                    <button
                      onClick={() => navigate('/payment')}
                      className="flex-1 bg-gray-800 hover:bg-gray-900 text-white py-4 border-2 border-gray-900"
                    >
                      [Proceed to Payment]
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Price Summary Card */}
          <div className="lg:col-span-1">
            <div className="bg-white border-2 border-gray-400 p-6 sticky top-24">
              <h3 className="text-gray-900 mb-6 border-b-2 border-gray-300 pb-3">[Price Summary]</h3>

              <div className="mb-6">
                <div className="w-full h-40 bg-gray-300 border-2 border-gray-400 flex items-center justify-center mb-4">
                  <span className="text-gray-600 text-sm">[Trip Image]</span>
                </div>
                <h4 className="text-gray-900 mb-2">{packageData.title}</h4>
                <p className="text-sm text-gray-600">{packageData.location}</p>
              </div>

              <div className="space-y-3 mb-6 pb-6 border-b-2 border-gray-300">
                <div className="flex justify-between text-gray-700">
                  <span>${packageData.pricePerPerson} × {packageData.travelers}</span>
                  <span>${totalPrice}</span>
                </div>
                <div className="flex justify-between text-gray-700">
                  <span>Taxes & Fees</span>
                  <span>${tax}</span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6 border-2 border-gray-400 p-4">
                <span className="text-gray-900">Total</span>
                <span className="text-gray-900 text-2xl">${grandTotal}</span>
              </div>

              <div className="space-y-3 border-t-2 border-gray-300 pt-4">
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>Free cancellation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>Instant confirmation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>24/7 support</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
