import { useNavigate } from 'react-router-dom';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { CheckCircle2, Download, Calendar, MapPin, Users, Mail, Phone, Home } from 'lucide-react';

export function ConfirmationPage() {
  const navigate = useNavigate();

  const bookingDetails = {
    bookingId: 'TW' + Math.random().toString(36).substr(2, 9).toUpperCase(),
    title: 'Luxury Maldives Resort Experience',
    location: 'Maldives',
    date: 'Dec 15, 2024',
    duration: '7 Days / 6 Nights',
    travelers: 2,
    totalPaid: 5497.8,
    email: 'john@example.com',
    phone: '+1 (555) 000-0000',
    image: '',
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Animation Placeholder */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 border-4 border-gray-700 bg-white mb-6">
            <CheckCircle2 className="w-16 h-16 text-gray-700" />
          </div>
          <h1 className="text-gray-900 mb-4 border-4 border-dashed border-gray-500 p-4 inline-block">
            [Booking Confirmed!]
          </h1>
          <p className="text-gray-700 text-xl border-2 border-gray-300 p-4 inline-block">
            Your dream vacation is all set
          </p>
        </div>

        {/* Booking ID Card */}
        <div className="bg-white border-4 border-gray-800 p-8 text-center mb-8">
          <p className="text-gray-600 mb-2">[Your Booking ID]</p>
          <h2 className="text-gray-900 text-4xl tracking-wider border-2 border-dashed border-gray-400 p-4 inline-block">{bookingDetails.bookingId}</h2>
          <p className="text-gray-600 mt-4 text-sm">
            Save this ID for reference
          </p>
        </div>

        {/* Trip Summary */}
        <div className="bg-white border-2 border-gray-400 mb-8">
          <div className="relative h-64 border-b-2 border-gray-400">
            <div className="w-full h-full bg-gray-300 flex items-center justify-center">
              <span className="text-gray-600">[Trip Banner Image]</span>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/90 border-t-2 border-gray-400">
              <h3 className="text-gray-900 mb-2">{bookingDetails.title}</h3>
              <div className="flex items-center gap-2 text-gray-700">
                <MapPin className="w-4 h-4" />
                <span>{bookingDetails.location}</span>
              </div>
            </div>
          </div>

          <div className="p-8">
            <h3 className="text-gray-900 mb-6 border-b-2 border-gray-300 pb-3">[Trip Details]</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4 p-4 border-2 border-gray-400">
                <div className="border-2 border-gray-500 p-3">
                  <Calendar className="w-6 h-6 text-gray-700" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Departure Date</p>
                  <p className="text-gray-900">{bookingDetails.date}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border-2 border-gray-400">
                <div className="border-2 border-gray-500 p-3">
                  <Users className="w-6 h-6 text-gray-700" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Travelers</p>
                  <p className="text-gray-900">{bookingDetails.travelers} People</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border-2 border-gray-400">
                <div className="border-2 border-gray-500 p-3">
                  <Mail className="w-6 h-6 text-gray-700" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="text-gray-900 text-sm">{bookingDetails.email}</p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 border-2 border-gray-400">
                <div className="border-2 border-gray-500 p-3">
                  <Phone className="w-6 h-6 text-gray-700" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Phone</p>
                  <p className="text-gray-900">{bookingDetails.phone}</p>
                </div>
              </div>
            </div>

            <div className="mt-6 p-6 border-2 border-gray-700">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Total Amount Paid</p>
                  <p className="text-gray-900 text-2xl">${bookingDetails.totalPaid}</p>
                </div>
                <div className="border-2 border-gray-700 px-4 py-2">
                  <span className="text-gray-900">[Payment Success]</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* What's Next */}
        <div className="bg-white border-2 border-gray-400 p-8 mb-8">
          <h3 className="text-gray-900 mb-6 border-b-2 border-gray-300 pb-3">[What's Next?]</h3>
          <div className="space-y-4">
            <div className="flex gap-4 border-l-4 border-gray-400 pl-4">
              <div className="flex-shrink-0 w-8 h-8 border-2 border-gray-700 flex items-center justify-center text-gray-900">
                1
              </div>
              <div>
                <h4 className="text-gray-900 mb-1">Check Your Email</h4>
                <p className="text-sm text-gray-600">
                  Confirmation email sent to {bookingDetails.email}
                </p>
              </div>
            </div>

            <div className="flex gap-4 border-l-4 border-gray-400 pl-4">
              <div className="flex-shrink-0 w-8 h-8 border-2 border-gray-700 flex items-center justify-center text-gray-900">
                2
              </div>
              <div>
                <h4 className="text-gray-900 mb-1">Download Your Tickets</h4>
                <p className="text-sm text-gray-600">
                  Download and print travel documents
                </p>
              </div>
            </div>

            <div className="flex gap-4 border-l-4 border-gray-400 pl-4">
              <div className="flex-shrink-0 w-8 h-8 border-2 border-gray-700 flex items-center justify-center text-gray-900">
                3
              </div>
              <div>
                <h4 className="text-gray-900 mb-1">Stay Connected</h4>
                <p className="text-sm text-gray-600">
                  24/7 support team available
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-900 text-white py-4 border-2 border-gray-900">
            <Download className="w-5 h-5" />
            [Download Ticket]
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 bg-white hover:bg-gray-100 text-gray-900 py-4 border-2 border-gray-400"
          >
            <Home className="w-5 h-5" />
            [Continue Browsing]
          </button>
        </div>

        {/* Contact Support */}
        <div className="mt-8 text-center p-6 border-2 border-gray-400">
          <p className="text-gray-600 mb-2">Need help with your booking?</p>
          <a href="#" className="text-gray-900 border-b-2 border-gray-700">
            [ Contact Customer Support → ]
          </a>
        </div>
      </div>

      <Footer />
    </div>
  );
}
