import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { CreditCard, Smartphone, Building2, Shield, Check, Lock } from 'lucide-react';

export function PaymentPage() {
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState('card');

  const orderSummary = {
    title: 'Luxury Maldives Resort Experience',
    location: 'Maldives',
    date: 'Dec 15, 2024',
    travelers: 2,
    subtotal: 4998,
    tax: 499.8,
    total: 5497.8,
    image: '',
  };

  const paymentMethods = [
    { id: 'card', icon: CreditCard, title: 'Credit/Debit Card', subtitle: 'Visa, Mastercard, Amex' },
    { id: 'upi', icon: Smartphone, title: 'UPI Payment', subtitle: 'Google Pay, PhonePe, Paytm' },
    { id: 'netbanking', icon: Building2, title: 'Net Banking', subtitle: 'All major banks' },
  ];

  const handlePayment = () => {
    navigate('/confirmation');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-gray-900 mb-8 border-b-2 border-gray-400 pb-4">[Secure Payment]</h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2">
            <div className="bg-white border-2 border-gray-400 p-8">
              {/* Payment Methods */}
              <h3 className="text-gray-900 mb-6 border-b border-gray-300 pb-3">[Select Payment Method]</h3>
              
              <div className="space-y-4 mb-8">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id)}
                    className={`flex items-center gap-4 p-4 border-2 cursor-pointer ${
                      paymentMethod === method.id
                        ? 'border-gray-800 bg-gray-100'
                        : 'border-gray-400'
                    }`}
                  >
                    <div className={`p-3 border-2 ${
                      paymentMethod === method.id ? 'border-gray-700' : 'border-gray-400'
                    }`}>
                      <method.icon className={`w-6 h-6 ${
                        paymentMethod === method.id ? 'text-gray-900' : 'text-gray-600'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-gray-900">{method.title}</h4>
                      <p className="text-sm text-gray-600">{method.subtitle}</p>
                    </div>
                    <div className={`w-6 h-6 border-2 flex items-center justify-center ${
                      paymentMethod === method.id
                        ? 'border-gray-800 bg-gray-800'
                        : 'border-gray-400'
                    }`}>
                      {paymentMethod === method.id && (
                        <Check className="w-4 h-4 text-white" />
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Card Details Form */}
              {paymentMethod === 'card' && (
                <div className="space-y-4 border-2 border-gray-300 p-6">
                  <div>
                    <label className="text-sm text-gray-700 mb-2 block">[Card Number *]</label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="text"
                        placeholder="1234 5678 9012 3456"
                        maxLength={19}
                        className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm text-gray-700 mb-2 block">[Cardholder Name *]</label>
                    <input
                      type="text"
                      placeholder="John Doe"
                      className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-700 mb-2 block">[Expiry *]</label>
                      <input
                        type="text"
                        placeholder="MM/YY"
                        maxLength={5}
                        className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-gray-700 mb-2 block">[CVV *]</label>
                      <input
                        type="text"
                        placeholder="123"
                        maxLength={3}
                        className="w-full px-4 py-3 bg-white border-2 border-gray-300"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* UPI Form */}
              {paymentMethod === 'upi' && (
                <div className="space-y-4 border-2 border-gray-300 p-6">
                  <div>
                    <label className="text-sm text-gray-700 mb-2 block">[UPI ID *]</label>
                    <div className="relative">
                      <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="text"
                        placeholder="yourname@upi"
                        className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Net Banking Form */}
              {paymentMethod === 'netbanking' && (
                <div className="space-y-4 border-2 border-gray-300 p-6">
                  <div>
                    <label className="text-sm text-gray-700 mb-2 block">[Select Bank *]</label>
                    <select className="w-full px-4 py-3 bg-white border-2 border-gray-300 appearance-none">
                      <option>Choose your bank</option>
                      <option>HDFC Bank</option>
                      <option>ICICI Bank</option>
                      <option>State Bank of India</option>
                      <option>Axis Bank</option>
                      <option>Kotak Mahindra Bank</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Security Badge */}
              <div className="mt-8 p-4 border-2 border-gray-400 flex items-start gap-3">
                <Shield className="w-6 h-6 text-gray-700 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-gray-900 mb-1">Secure Payment</h4>
                  <p className="text-sm text-gray-700">
                    Your payment information is encrypted. SSL encryption protects your data.
                  </p>
                </div>
              </div>

              <button
                onClick={handlePayment}
                className="w-full mt-8 bg-gray-800 hover:bg-gray-900 text-white py-4 border-2 border-gray-900 flex items-center justify-center gap-2"
              >
                <Lock className="w-5 h-5" />
                [Pay Securely] ${orderSummary.total}
              </button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white border-2 border-gray-400 p-6 sticky top-24">
              <h3 className="text-gray-900 mb-6 border-b-2 border-gray-300 pb-3">[Order Summary]</h3>

              <div className="mb-6">
                <div className="w-full h-40 bg-gray-300 border-2 border-gray-400 flex items-center justify-center mb-4">
                  <span className="text-gray-600 text-sm">[Trip Image]</span>
                </div>
                <h4 className="text-gray-900 mb-2">{orderSummary.title}</h4>
                <p className="text-sm text-gray-600 mb-1">{orderSummary.location}</p>
                <p className="text-sm text-gray-600">Departure: {orderSummary.date}</p>
              </div>

              <div className="space-y-3 mb-6 pb-6 border-b-2 border-gray-300">
                <div className="flex justify-between">
                  <span className="text-gray-600">Travelers</span>
                  <span className="text-gray-900">{orderSummary.travelers} People</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900">${orderSummary.subtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Taxes & Fees</span>
                  <span className="text-gray-900">${orderSummary.tax}</span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6 border-2 border-gray-400 p-4">
                <span className="text-gray-900">Total</span>
                <span className="text-gray-900 text-2xl">${orderSummary.total}</span>
              </div>

              <div className="space-y-3 p-4 border-2 border-gray-400">
                <div className="flex items-center gap-2 text-sm text-gray-800">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>Instant confirmation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-800">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>Free cancellation</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-800">
                  <Check className="w-4 h-4 text-gray-700" />
                  <span>24/7 support</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
