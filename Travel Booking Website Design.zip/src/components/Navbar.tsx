import { Link } from 'react-router-dom';
import { Plane, User, Menu } from 'lucide-react';

export function Navbar() {
  return (
    <nav className="bg-white border-b-2 border-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="border-2 border-gray-400 p-2">
              <Plane className="w-6 h-6 text-gray-700" />
            </div>
            <span className="text-gray-900">TravelWings</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-gray-700 border-b-2 border-transparent hover:border-gray-700">
              Home
            </Link>
            <Link to="/search" className="text-gray-700 border-b-2 border-transparent hover:border-gray-700">
              Destinations
            </Link>
            <a href="#packages" className="text-gray-700 border-b-2 border-transparent hover:border-gray-700">
              Packages
            </a>
            <a href="#deals" className="text-gray-700 border-b-2 border-transparent hover:border-gray-700">
              Deals
            </a>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 border border-gray-400">
              <User className="w-5 h-5 text-gray-700" />
            </button>
            <button className="md:hidden p-2 border border-gray-400">
              <Menu className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}