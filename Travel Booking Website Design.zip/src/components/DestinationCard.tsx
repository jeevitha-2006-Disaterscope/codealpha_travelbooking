import { MapPin, ArrowRight } from 'lucide-react';

interface DestinationCardProps {
  image: string;
  name: string;
  country: string;
  trips: number;
}

export function DestinationCard({ image, name, country, trips }: DestinationCardProps) {
  return (
    <div className="border-2 border-gray-400 cursor-pointer">
      {/* Image Placeholder */}
      <div className="w-full h-72 bg-gray-300 flex items-center justify-center border-b-2 border-gray-400">
        <span className="text-gray-600 text-sm">[Image: {name}]</span>
      </div>
      
      <div className="p-6 bg-white">
        <div className="flex items-center gap-2 mb-2">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{country}</span>
        </div>
        <h3 className="text-gray-900 mb-2">{name}</h3>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-700">{trips} trips available</span>
          <ArrowRight className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}