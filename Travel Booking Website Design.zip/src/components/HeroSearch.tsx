import { Search, MapPin, Calendar, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function HeroSearch() {
  const navigate = useNavigate();

  const handleSearch = () => {
    navigate('/search');
  };

  return (
    <div className="bg-white border-2 border-gray-400 p-6 max-w-5xl mx-auto -mt-8 relative z-10">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="md:col-span-1">
          <label className="text-sm text-gray-700 mb-2 block">[From]</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Your city"
              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
            />
          </div>
        </div>

        <div className="md:col-span-1">
          <label className="text-sm text-gray-700 mb-2 block">[To]</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-700" />
            <input
              type="text"
              placeholder="Destination"
              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
            />
          </div>
        </div>

        <div className="md:col-span-1">
          <label className="text-sm text-gray-700 mb-2 block">[Check-in]</label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="date"
              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
            />
          </div>
        </div>

        <div className="md:col-span-1">
          <label className="text-sm text-gray-700 mb-2 block">[Check-out]</label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="date"
              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300"
            />
          </div>
        </div>

        <div className="md:col-span-1">
          <label className="text-sm text-gray-700 mb-2 block">[Travelers]</label>
          <div className="relative">
            <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <select className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-300 appearance-none">
              <option>1 Person</option>
              <option>2 People</option>
              <option>3 People</option>
              <option>4+ People</option>
            </select>
          </div>
        </div>
      </div>

      <button
        onClick={handleSearch}
        className="w-full md:w-auto mt-4 bg-gray-800 hover:bg-gray-900 text-white px-8 py-3 border-2 border-gray-900 flex items-center justify-center gap-2"
      >
        <Search className="w-5 h-5" />
        [Search Trips]
      </button>
    </div>
  );
}