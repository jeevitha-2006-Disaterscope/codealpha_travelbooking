import { Plane, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-200 border-t-2 border-gray-400 text-gray-900 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="border-2 border-gray-600 p-2">
                <Plane className="w-5 h-5 text-gray-700" />
              </div>
              <span className="text-gray-900">TravelWings</span>
            </div>
            <p className="text-gray-700 text-sm border-l-2 border-gray-400 pl-2">
              [Logo description text placeholder]
            </p>
          </div>

          <div>
            <h4 className="mb-4 text-gray-900 border-b border-gray-400 pb-2">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-700 text-sm">[ About Us ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ Destinations ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ Tour Packages ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ Contact ]</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-gray-900 border-b border-gray-400 pb-2">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-700 text-sm">[ Help Center ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ Terms of Service ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ Privacy Policy ]</a></li>
              <li><a href="#" className="text-gray-700 text-sm">[ FAQs ]</a></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-gray-900 border-b border-gray-400 pb-2">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-gray-700 text-sm">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2 text-gray-700 text-sm">
                <Mail className="w-4 h-4" />
                <span>info@travelwings.com</span>
              </li>
              <li className="flex items-center gap-2 text-gray-700 text-sm">
                <MapPin className="w-4 h-4" />
                <span>123 Travel St, NY</span>
              </li>
            </ul>
            <div className="flex gap-3 mt-4">
              <a href="#" className="border-2 border-gray-600 p-2">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="border-2 border-gray-600 p-2">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="border-2 border-gray-600 p-2">
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t-2 border-gray-400 mt-8 pt-8 text-center text-gray-700 text-sm">
          <p>© 2024 TravelWings. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}