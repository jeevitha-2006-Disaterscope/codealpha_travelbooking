import { Star, Clock, Users, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PackageCardProps {
  id: string;
  image: string;
  title: string;
  location: string;
  duration: string;
  groupSize: string;
  rating: number;
  reviews: number;
  price: number;
  originalPrice?: number;
}

export function PackageCard({
  id,
  image,
  title,
  location,
  duration,
  groupSize,
  rating,
  reviews,
  price,
  originalPrice,
}: PackageCardProps) {
  const navigate = useNavigate();

  return (
    <div className="bg-white border-2 border-gray-400 cursor-pointer">
      {/* Image Placeholder */}
      <div className="relative">
        <div className="w-full h-56 bg-gray-300 flex items-center justify-center border-b-2 border-gray-400">
          <span className="text-gray-600 text-sm">[Package Image]</span>
        </div>
        {originalPrice && (
          <div className="absolute top-4 right-4 bg-white border-2 border-gray-700 px-3 py-1 text-sm">
            -${originalPrice - price}
          </div>
        )}
        <div className="absolute top-4 left-4 bg-white border border-gray-400 px-3 py-1 text-sm flex items-center gap-1">
          <Star className="w-4 h-4 text-gray-700" />
          <span>{rating}</span>
          <span className="text-gray-500">({reviews})</span>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-center gap-2 text-gray-600 text-sm mb-2">
          <MapPin className="w-4 h-4 text-gray-700" />
          <span>{location}</span>
        </div>

        <h3 className="mb-3 text-gray-900 line-clamp-2">{title}</h3>

        <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{groupSize}</span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t-2 border-gray-300">
          <div>
            {originalPrice && (
              <span className="text-sm text-gray-500 line-through mr-2">
                ${originalPrice}
              </span>
            )}
            <span className="text-gray-900">
              ${price}
            </span>
            <span className="text-sm text-gray-600"> /person</span>
          </div>
          <button
            onClick={() => navigate(`/package/${id}`)}
            className="bg-gray-800 hover:bg-gray-900 text-white px-5 py-2 border-2 border-gray-900"
          >
            [View]
          </button>
        </div>
      </div>
    </div>
  );
}