import { DollarSign, Clock, Plane, Star, SlidersHorizontal } from 'lucide-react';

export function FilterSidebar() {
  return (
    <div className="bg-white border-2 border-gray-400 p-6 sticky top-24">
      <div className="flex items-center gap-2 mb-6 pb-3 border-b-2 border-gray-300">
        <SlidersHorizontal className="w-5 h-5 text-gray-700" />
        <h3 className="text-gray-900">[Filters]</h3>
      </div>

      {/* Price Range */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <DollarSign className="w-4 h-4 text-gray-600" />
          <h4 className="text-gray-900">Price Range</h4>
        </div>
        <input
          type="range"
          min="0"
          max="5000"
          className="w-full"
        />
        <div className="flex justify-between text-sm text-gray-600 mt-2">
          <span>$0</span>
          <span>$5000+</span>
        </div>
      </div>

      {/* Duration */}
      <div className="mb-6 pb-6 border-b border-gray-300">
        <div className="flex items-center gap-2 mb-3">
          <Clock className="w-4 h-4 text-gray-600" />
          <h4 className="text-gray-900">Duration</h4>
        </div>
        <div className="space-y-2">
          {['1-3 Days', '4-7 Days', '8-14 Days', '15+ Days'].map((duration) => (
            <label key={duration} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="border-2 border-gray-400" />
              <span className="text-sm text-gray-700">[ ] {duration}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Trip Type */}
      <div className="mb-6 pb-6 border-b border-gray-300">
        <div className="flex items-center gap-2 mb-3">
          <Plane className="w-4 h-4 text-gray-600" />
          <h4 className="text-gray-900">Trip Type</h4>
        </div>
        <div className="space-y-2">
          {['Adventure', 'Beach', 'City Tour', 'Cruise', 'Cultural', 'Wildlife'].map((type) => (
            <label key={type} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="border-2 border-gray-400" />
              <span className="text-sm text-gray-700">[ ] {type}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Rating */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Star className="w-4 h-4 text-gray-600" />
          <h4 className="text-gray-900">Rating</h4>
        </div>
        <div className="space-y-2">
          {[5, 4, 3, 2].map((rating) => (
            <label key={rating} className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" className="border-2 border-gray-400" />
              <div className="flex items-center gap-1">
                {[...Array(rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gray-700" />
                ))}
                <span className="text-sm text-gray-700 ml-1">& up</span>
              </div>
            </label>
          ))}
        </div>
      </div>

      <button className="w-full bg-gray-800 hover:bg-gray-900 text-white py-3 border-2 border-gray-900">
        [Apply Filters]
      </button>
    </div>
  );
}